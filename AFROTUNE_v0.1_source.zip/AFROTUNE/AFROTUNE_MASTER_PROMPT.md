# AFROTUNE: Master Prompt

Paste everything below the line into Claude Code (or any coding AI). Attach the project folder if you want it to extend the starter.

---

You are a senior audio DSP engineer and JUCE/C++ plugin developer. Build **AFROTUNE**, a real-time pitch-correction (auto-tune) plugin for **FL Studio on Windows**, by Launchpad Music (producer: Hitsound).

## Product vision
AFROTUNE is the auto-tune built for African music: Afrobeats, Amapiano, Afro-fusion, Highlife, Gqom, Afro-drill. It is not a generic clone. It should sound modern, glide the way Afrobeats vocals glide, and be usable in under 10 seconds.

## Technical requirements
1. **Framework:** JUCE 8, CMake build. Formats: **VST3** (primary, for FL Studio) and Standalone for testing. Windows x64, MSVC.
2. **Real-time safe:** no allocations, locks, file I/O or logging in `processBlock`. Preallocate in `prepareToPlay`. Handle mono and stereo, any sample rate 44.1k to 192k, any block size, including 1 sample.
3. **Pitch detection:** YIN or MPM, with a voiced/unvoiced decision, a 70 Hz to 1 kHz range, octave-error protection and silence gating.
4. **Pitch shifting:** start with a time-domain shifter. Then upgrade to PSOLA or a phase vocoder with formant preservation, so a corrected voice does not become "chipmunk" or "monster".
5. **Correction engine:** nearest-note quantization to a chosen key and scale, **retune speed** (0 ms = hard T-Pain effect, 20 to 60 ms = modern Afro vocal, 200 ms+ = natural), **amount**, and **mix**.
6. **Afro scales (built in):** Chromatic, Major, Minor, Minor Pentatonic (Afrobeats), Major Pentatonic (Highlife), Dorian (Amapiano), Mixolydian, Harmonic Minor.
7. **Latency:** report it correctly via `setLatencySamples` so FL Studio's plugin delay compensation aligns the track. Keep it under 30 ms.
8. **State:** use `AudioProcessorValueTreeState` for all parameters, with full save/restore and automation support in FL Studio.

## Features by version
- **v1:** the features above, with a branded UI showing the detected note and the target note live.
- **v2:** MIDI input to force target notes, formant control, vibrato and humanize controls, a "Glide" control for slides between notes, and a preset browser (Afrobeats Smooth, Amapiano Slide, Hard Tune, Natural Fix).
- **v3:** per-note enable and disable on a piano roll, scale detection from audio, a stereo widener, and an optional subtle saturation stage.

## UI and brand
Dark background, Nigerian green (#00A651) and gold (#F5B700) accents, bold "AFROTUNE" wordmark, and "by Launchpad Music" in small type. Large rotary knobs for Speed, Amount and Mix. Key and Scale dropdowns. A live pitch display. The UI must be crisp at 100% to 200% scaling.

## Deliverables
- A complete, compiling CMake project with every source file.
- A GitHub Actions workflow that builds the Windows VST3 on every push and uploads it as an artifact.
- Install instructions for FL Studio: copy to `C:\Program Files\Common Files\VST3`, then Options > Manage plugins > Find plugins.
- A test checklist: sine sweeps, sung samples, silence, clipping input, 44.1/48/96 kHz, buffer sizes 64 to 2048.
- A short roadmap for licensing, installer (Inno Setup), code signing and copy protection, because this will be sold.

## Working method
1. Plan the architecture first, in 10 lines.
2. Build and verify each DSP stage in isolation (detector, quantizer, shifter) before wiring them together.
3. After each stage, state exactly what was tested and what was not.
4. Never claim it compiles or sounds good unless you actually built and tested it. Flag every assumption.
