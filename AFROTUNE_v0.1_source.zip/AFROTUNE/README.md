# AFROTUNE v0.1 (starter)

Real-time pitch correction VST3 for FL Studio, by Launchpad Music.

## What's in v0.1
- YIN pitch detection (70 Hz to 1 kHz) with silence gating and a voiced/unvoiced decision
- Scale quantizer with 8 scales, including Afrobeats Minor Pentatonic, Highlife Major Pentatonic and Amapiano Dorian
- Retune Speed (0 to 400 ms), Amount and Mix
- Time-domain pitch shifter (two-tap crossfade) with latency reporting for FL Studio's delay compensation
- Branded UI with a live detected-note to target-note readout

## Verified status
- **Compiles** cleanly (JUCE 8.0.4, GCC, Linux): VST3 + Standalone targets built. One compile error in the editor was found and fixed.
- **DSP test suite passes (9/9)** via `test/dsp_test.cpp`: out-of-tune inputs land within about 3 cents of the target note at 44.1/48/96 kHz and block sizes 64 to 512, in-tune input is left alone, Mix = 0 passes the dry signal, and silence in gives silence out.
- **Not yet done:** a Windows build and a test inside FL Studio. The Windows VST3 comes from the GitHub Actions workflow. Nobody has listened to it on a real vocal yet, so the sound quality (the simple shifter can be a bit phasey or grainy) is unjudged.

Run the tests yourself: `cmake -B build -DAFROTUNE_BUILD_TESTS=ON && cmake --build build --target afrotune_test && ./build/afrotune_test`

## Build (easiest: no install needed)
1. Create a new GitHub repo and upload this whole folder.
2. Open the **Actions** tab. The "Build AFROTUNE" workflow runs on push.
3. When it finishes, download the **AFROTUNE-VST3** artifact.

## Build locally (Windows)
Requires Visual Studio 2022 (Desktop C++) and CMake.

```
cmake -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```

Output: `build/AFROTUNE_artefacts/Release/VST3/AFROTUNE.vst3`

## Install in FL Studio
1. Copy `AFROTUNE.vst3` to `C:\Program Files\Common Files\VST3\`
2. FL Studio: Options > Manage plugins > Find plugins
3. Add AFROTUNE to a mixer insert on your vocal track.

## Suggested settings
| Sound | Key/Scale | Retune Speed |
|---|---|---|
| Hard T-Pain effect | song key, Chromatic or Minor | 0 ms |
| Modern Afrobeats vocal | song key, Minor Pentatonic | 20 to 40 ms |
| Amapiano smooth | song key, Dorian | 50 to 80 ms |
| Natural fix | song key, Major or Minor | 150 ms+ |

## Next steps
Test, then follow the roadmap in `AFROTUNE_MASTER_PROMPT.md` (formant preservation, MIDI input, presets, installer, licensing).
