#include "PluginEditor.h"

namespace
{
    const juce::Colour kBg    { 0xff0b0f0c };
    const juce::Colour kPanel { 0xff141b16 };
    const juce::Colour kGreen { 0xff00a651 };
    const juce::Colour kGold  { 0xfff5b700 };

    juce::String noteName (float midi)
    {
        static const char* names[] = { "C","C#","D","D#","E","F","F#","G","G#","A","A#","B" };
        const int n = (int) std::round (midi);
        return juce::String (names[((n % 12) + 12) % 12]) + juce::String ((n / 12) - 1);
    }

    void styleKnob (juce::Slider& s)
    {
        s.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 80, 20);
        s.setColour (juce::Slider::rotarySliderFillColourId, kGreen);
        s.setColour (juce::Slider::rotarySliderOutlineColourId, kPanel.brighter (0.2f));
        s.setColour (juce::Slider::thumbColourId, kGold);
        s.setColour (juce::Slider::textBoxTextColourId, juce::Colours::white);
        s.setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    }

    void styleLabel (juce::Label& l, const juce::String& text)
    {
        l.setText (text, juce::dontSendNotification);
        l.setJustificationType (juce::Justification::centred);
        l.setColour (juce::Label::textColourId, kGold);
        l.setFont (juce::FontOptions (13.0f, juce::Font::bold));
    }
}

AfroTuneEditor::AfroTuneEditor (AfroTuneProcessor& p)
    : AudioProcessorEditor (&p), proc (p)
{
    keyBox.addItemList (AfroTuneProcessor::getKeyNames(), 1);
    scaleBox.addItemList (AfroTuneProcessor::getScaleNames(), 1);

    styleKnob (speedKnob);
    styleKnob (amountKnob);
    styleKnob (mixKnob);
    amountKnob.setNumDecimalPlacesToDisplay (2);
    mixKnob.setNumDecimalPlacesToDisplay (2);
    speedKnob.setTextValueSuffix (" ms");

    styleLabel (keyLabel, "KEY");
    styleLabel (scaleLabel, "SCALE");
    styleLabel (speedLabel, "RETUNE SPEED");
    styleLabel (amountLabel, "AMOUNT");
    styleLabel (mixLabel, "MIX");

    for (juce::Component* c : { (juce::Component*) &keyBox, (juce::Component*) &scaleBox,
                                (juce::Component*) &speedKnob, (juce::Component*) &amountKnob,
                                (juce::Component*) &mixKnob, (juce::Component*) &keyLabel,
                                (juce::Component*) &scaleLabel, (juce::Component*) &speedLabel,
                                (juce::Component*) &amountLabel, (juce::Component*) &mixLabel })
        addAndMakeVisible (c);

    keyAtt    = std::make_unique<ComboAtt> (proc.apvts, "key", keyBox);
    scaleAtt  = std::make_unique<ComboAtt> (proc.apvts, "scale", scaleBox);
    speedAtt  = std::make_unique<SliderAtt> (proc.apvts, "speed", speedKnob);
    amountAtt = std::make_unique<SliderAtt> (proc.apvts, "amount", amountKnob);
    mixAtt    = std::make_unique<SliderAtt> (proc.apvts, "mix", mixKnob);

    setSize (560, 420);
    startTimerHz (30);
}

void AfroTuneEditor::paint (juce::Graphics& g)
{
    g.fillAll (kBg);

    // Header
    g.setGradientFill (juce::ColourGradient (kGreen, 0.0f, 0.0f, kGold, (float) getWidth(), 0.0f, false));
    g.fillRect (0, 0, getWidth(), 4);

    g.setColour (juce::Colours::white);
    g.setFont (juce::FontOptions (36.0f, juce::Font::bold));
    g.drawText ("AFRO", 24, 14, 100, 44, juce::Justification::centredLeft);
    g.setColour (kGold);
    g.drawText ("TUNE", 108, 14, 120, 44, juce::Justification::centredLeft);

    g.setColour (juce::Colours::grey);
    g.setFont (juce::FontOptions (12.0f));
    g.drawText ("by Launchpad Music", getWidth() - 184, 22, 160, 20, juce::Justification::centredRight);

    // Pitch readout
    g.setColour (kPanel);
    g.fillRoundedRectangle (readoutArea.toFloat(), 10.0f);

    const float det = proc.detectedMidi.load();
    const float tgt = proc.correctedMidi.load();
    g.setFont (juce::FontOptions (26.0f, juce::Font::bold));
    if (det > 0.0f)
    {
        g.setColour (juce::Colours::white);
        g.drawText (noteName (det), readoutArea.removeFromLeft (readoutArea.getWidth() / 2),
                    juce::Justification::centred);
        g.setColour (kGreen);
        g.drawText (juce::String (juce::CharPointer_UTF8 ("\xe2\x86\x92 ")) + noteName (tgt),
                    readoutArea.withTrimmedLeft (0), juce::Justification::centred);
    }
    else
    {
        g.setColour (juce::Colours::grey);
        g.drawText ("listening...", readoutArea, juce::Justification::centred);
    }
}

void AfroTuneEditor::resized()
{
    auto area = getLocalBounds().reduced (24);
    area.removeFromTop (50);

    readoutArea = area.removeFromTop (60);
    area.removeFromTop (14);

    auto row = area.removeFromTop (54);
    auto left = row.removeFromLeft (row.getWidth() / 2).reduced (6, 0);
    auto right = row.reduced (6, 0);
    keyLabel.setBounds (left.removeFromTop (16));
    keyBox.setBounds (left.removeFromTop (30));
    scaleLabel.setBounds (right.removeFromTop (16));
    scaleBox.setBounds (right.removeFromTop (30));

    area.removeFromTop (14);
    auto knobs = area;
    const int w = knobs.getWidth() / 3;
    auto place = [&] (juce::Slider& knob, juce::Label& label)
    {
        auto cell = knobs.removeFromLeft (w).reduced (8, 0);
        label.setBounds (cell.removeFromTop (18));
        knob.setBounds (cell);
    };
    place (speedKnob, speedLabel);
    place (amountKnob, amountLabel);
    place (mixKnob, mixLabel);
}
