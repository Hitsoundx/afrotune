#pragma once
#include "PluginProcessor.h"

class AfroTuneEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit AfroTuneEditor (AfroTuneProcessor&);
    ~AfroTuneEditor() override { stopTimer(); }

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override { repaint (readoutArea); }

    AfroTuneProcessor& proc;

    juce::ComboBox keyBox, scaleBox;
    juce::Slider speedKnob, amountKnob, mixKnob;
    juce::Label keyLabel, scaleLabel, speedLabel, amountLabel, mixLabel;

    juce::Rectangle<int> readoutArea;

    using SliderAtt = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboAtt  = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    std::unique_ptr<ComboAtt> keyAtt, scaleAtt;
    std::unique_ptr<SliderAtt> speedAtt, amountAtt, mixAtt;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (AfroTuneEditor)
};
