#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>

namespace
{
    // Scale masks: bit n set = semitone n above the root is allowed
    constexpr int mk (std::initializer_list<int> notes)
    {
        int m = 0;
        for (int n : notes) m |= (1 << n);
        return m;
    }

    const int kScaleMasks[] = {
        mk ({0,1,2,3,4,5,6,7,8,9,10,11}), // Chromatic
        mk ({0,2,4,5,7,9,11}),            // Major
        mk ({0,2,3,5,7,8,10}),            // Minor
        mk ({0,3,5,7,10}),                // Minor Pentatonic (Afrobeats)
        mk ({0,2,4,7,9}),                 // Major Pentatonic (Highlife)
        mk ({0,2,3,5,7,9,10}),            // Dorian (Amapiano)
        mk ({0,2,4,5,7,9,10}),            // Mixolydian
        mk ({0,2,3,5,7,8,11})             // Harmonic Minor
    };

    constexpr float kMinHz = 70.0f;
    constexpr float kMaxHz = 1000.0f;
    constexpr int   kWindow = 1024;
}

juce::StringArray AfroTuneProcessor::getKeyNames()
{
    return { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
}

juce::StringArray AfroTuneProcessor::getScaleNames()
{
    return { "Chromatic", "Major", "Minor", "Minor Pentatonic (Afrobeats)",
             "Major Pentatonic (Highlife)", "Dorian (Amapiano)", "Mixolydian", "Harmonic Minor" };
}

juce::AudioProcessorValueTreeState::ParameterLayout AfroTuneProcessor::createLayout()
{
    using namespace juce;
    std::vector<std::unique_ptr<RangedAudioParameter>> p;

    p.push_back (std::make_unique<AudioParameterChoice> (ParameterID { "key", 1 }, "Key", getKeyNames(), 0));
    p.push_back (std::make_unique<AudioParameterChoice> (ParameterID { "scale", 1 }, "Scale", getScaleNames(), 3));
    p.push_back (std::make_unique<AudioParameterFloat> (ParameterID { "speed", 1 }, "Retune Speed",
                    NormalisableRange<float> (0.0f, 400.0f, 0.1f, 0.5f), 25.0f,
                    AudioParameterFloatAttributes().withLabel ("ms")));
    p.push_back (std::make_unique<AudioParameterFloat> (ParameterID { "amount", 1 }, "Amount",
                    NormalisableRange<float> (0.0f, 1.0f, 0.001f), 1.0f));
    p.push_back (std::make_unique<AudioParameterFloat> (ParameterID { "mix", 1 }, "Mix",
                    NormalisableRange<float> (0.0f, 1.0f, 0.001f), 1.0f));

    return { p.begin(), p.end() };
}

AfroTuneProcessor::AfroTuneProcessor()
    : AudioProcessor (BusesProperties()
                        .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                        .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "AFROTUNE_STATE", createLayout())
{
}

bool AfroTuneProcessor::isBusesLayoutSupported (const BusesLayout& l) const
{
    const auto& out = l.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo())
        return false;
    return out == l.getMainInputChannelSet();
}

void AfroTuneProcessor::prepareToPlay (double sampleRate, int)
{
    fs = sampleRate;

    grain = (float) juce::jmin (0.03 * fs, 4096.0);
    const int size = 16384;
    for (auto& b : delayBuf) b.assign ((size_t) size, 0.0f);
    delayMask = size - 1;
    writePos = 0;
    phase = 0.0f;

    decim = juce::jmax (1, (int) std::round (fs / 24000.0));
    detFs = fs / decim;
    decimCount = 0;
    decimAcc = 0.0f;
    hist.assign (4096, 0.0f);
    histMask = 4095;
    detWrite = 0;

    hopSize = 512;
    hopCounter = 0;
    tauMin = juce::jmax (2, (int) (detFs / kMaxHz));
    tauMax = (int) (detFs / kMinHz) + 2;
    win.assign ((size_t) (kWindow + tauMax + 2), 0.0f);
    dfn.assign ((size_t) (tauMax + 2), 0.0f);
    cmnd.assign ((size_t) (tauMax + 2), 0.0f);

    hopOffset = smoothOffset = 0.0f;
    unvoicedHops = 0;
    sampleSmoothCoeff = 1.0f - std::exp (-1.0f / (0.003f * (float) fs));

    setLatencySamples ((int) (0.5f * grain + 1.0f));
}

float AfroTuneProcessor::readDelay (const std::vector<float>& b, float d) const
{
    const float rp = (float) writePos - d;
    const int i0 = (int) std::floor (rp);
    const float fr = rp - (float) i0;
    const int a = i0 & delayMask;
    const int c = (i0 + 1) & delayMask;
    return b[(size_t) a] + fr * (b[(size_t) c] - b[(size_t) a]);
}

void AfroTuneProcessor::feedDetector (float x)
{
    decimAcc += x;
    if (++decimCount >= decim)
    {
        hist[(size_t) detWrite] = decimAcc / (float) decim;
        detWrite = (detWrite + 1) & histMask;
        decimAcc = 0.0f;
        decimCount = 0;
    }
}

// YIN pitch detector. Returns Hz, or 0 if unvoiced.
float AfroTuneProcessor::yinDetect()
{
    const int total = kWindow + tauMax + 1;
    for (int k = 0; k < total; ++k)
        win[(size_t) k] = hist[(size_t) ((detWrite - total + k) & histMask)];

    // Silence gate
    float energy = 0.0f;
    for (int k = 0; k < kWindow; ++k) energy += win[(size_t) k] * win[(size_t) k];
    if (std::sqrt (energy / (float) kWindow) < 0.004f) return 0.0f;

    // Difference function
    for (int tau = 1; tau <= tauMax; ++tau)
    {
        float s = 0.0f;
        for (int j = 0; j < kWindow; ++j)
        {
            const float d = win[(size_t) j] - win[(size_t) (j + tau)];
            s += d * d;
        }
        dfn[(size_t) tau] = s;
    }

    // Cumulative mean normalised difference
    cmnd[0] = 1.0f;
    float running = 0.0f;
    for (int tau = 1; tau <= tauMax; ++tau)
    {
        running += dfn[(size_t) tau];
        cmnd[(size_t) tau] = running > 0.0f ? dfn[(size_t) tau] * (float) tau / running : 1.0f;
    }

    // Absolute threshold, then walk down to the local minimum
    int best = -1;
    for (int tau = tauMin; tau < tauMax; ++tau)
    {
        if (cmnd[(size_t) tau] < 0.15f)
        {
            while (tau + 1 < tauMax && cmnd[(size_t) (tau + 1)] < cmnd[(size_t) tau]) ++tau;
            best = tau;
            break;
        }
    }
    if (best < 0) return 0.0f;

    // Parabolic interpolation
    float refined = (float) best;
    if (best > 1 && best < tauMax)
    {
        const float s0 = cmnd[(size_t) (best - 1)], s1 = cmnd[(size_t) best], s2 = cmnd[(size_t) (best + 1)];
        const float den = 2.0f * (s0 - 2.0f * s1 + s2);
        if (std::abs (den) > 1e-9f) refined += (s0 - s2) / den;
    }
    const float hz = (float) detFs / refined;
    return (hz >= kMinHz && hz <= kMaxHz) ? hz : 0.0f;
}

void AfroTuneProcessor::analyse (int keyIdx, int scaleIdx, float speedMs, float amount)
{
    const float hz = yinDetect();
    float rawOffset = 0.0f;

    if (hz > 0.0f)
    {
        unvoicedHops = 0;
        const float midi = 69.0f + 12.0f * std::log2 (hz / 440.0f);
        const int mask = kScaleMasks[juce::jlimit (0, 7, scaleIdx)];
        const int base = (int) std::round (midi);

        float bestNote = (float) base, bestDist = 1e9f;
        for (int n = base - 6; n <= base + 6; ++n)
        {
            const int pc = (((n - keyIdx) % 12) + 12) % 12;
            if (mask & (1 << pc))
            {
                const float dist = std::abs ((float) n - midi);
                if (dist < bestDist) { bestDist = dist; bestNote = (float) n; }
            }
        }
        rawOffset = (bestNote - midi) * amount;
        detectedMidi.store (midi);
        correctedMidi.store (bestNote);
    }
    else
    {
        if (++unvoicedHops > 3)
        {
            rawOffset = 0.0f;
            detectedMidi.store (-1.0f);
            correctedMidi.store (-1.0f);
        }
        else
            rawOffset = hopOffset; // hold briefly through short dropouts
    }

    // Retune speed (one-pole per analysis hop)
    if (speedMs <= 0.5f)
        hopOffset = rawOffset;
    else
    {
        const float hopSec = (float) hopSize / (float) fs;
        const float a = 1.0f - std::exp (-hopSec / (speedMs * 0.001f));
        hopOffset += (rawOffset - hopOffset) * a;
    }
}

void AfroTuneProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    const int nCh = juce::jmin (buffer.getNumChannels(), 2);
    const int n = buffer.getNumSamples();
    for (int ch = nCh; ch < buffer.getNumChannels(); ++ch) buffer.clear (ch, 0, n);
    if (nCh == 0) return;

    const int   keyIdx   = (int) apvts.getRawParameterValue ("key")->load();
    const int   scaleIdx = (int) apvts.getRawParameterValue ("scale")->load();
    const float speedMs  = apvts.getRawParameterValue ("speed")->load();
    const float amount   = apvts.getRawParameterValue ("amount")->load();
    const float mix      = apvts.getRawParameterValue ("mix")->load();

    float* io[2] = { buffer.getWritePointer (0), nCh > 1 ? buffer.getWritePointer (1) : nullptr };

    for (int i = 0; i < n; ++i)
    {
        float mono = 0.0f;
        for (int ch = 0; ch < nCh; ++ch)
        {
            delayBuf[ch][(size_t) writePos] = io[ch][i];
            mono += io[ch][i];
        }
        mono /= (float) nCh;

        feedDetector (mono);
        if (++hopCounter >= hopSize)
        {
            hopCounter = 0;
            analyse (keyIdx, scaleIdx, speedMs, amount);
        }

        smoothOffset += (hopOffset - smoothOffset) * sampleSmoothCoeff;
        const float ratio = std::exp2 (smoothOffset / 12.0f);

        phase += (1.0f - ratio) / grain;
        phase -= std::floor (phase);
        float p2 = phase + 0.5f;
        p2 -= std::floor (p2);

        const float d1 = phase * grain + 1.0f;
        const float d2 = p2 * grain + 1.0f;
        const float g1 = 0.5f - 0.5f * std::cos (juce::MathConstants<float>::twoPi * phase);
        const float g2 = 0.5f - 0.5f * std::cos (juce::MathConstants<float>::twoPi * p2);

        // Avoid comb-filtering when no correction is needed: blend to aligned dry
        const float shiftAmt = juce::jlimit (0.0f, 1.0f, std::abs (smoothOffset) * 20.0f);
        const float dryDelay = 0.5f * grain + 1.0f;

        for (int ch = 0; ch < nCh; ++ch)
        {
            const float dry = readDelay (delayBuf[ch], dryDelay);
            const float shifted = g1 * readDelay (delayBuf[ch], d1) + g2 * readDelay (delayBuf[ch], d2);
            const float wet = dry + shiftAmt * (shifted - dry);
            io[ch][i] = dry * (1.0f - mix) + wet * mix;
        }

        writePos = (writePos + 1) & delayMask;
    }
}

juce::AudioProcessorEditor* AfroTuneProcessor::createEditor() { return new AfroTuneEditor (*this); }

void AfroTuneProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary (*xml, dest);
}

void AfroTuneProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new AfroTuneProcessor(); }
