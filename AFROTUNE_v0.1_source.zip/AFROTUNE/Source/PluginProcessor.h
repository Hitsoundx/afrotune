#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <atomic>
#include <vector>

class AfroTuneProcessor : public juce::AudioProcessor
{
public:
    AfroTuneProcessor();
    ~AfroTuneProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout&) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "AFROTUNE"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    static juce::StringArray getKeyNames();
    static juce::StringArray getScaleNames();

    juce::AudioProcessorValueTreeState apvts;

    // For the UI (written from audio thread, read from message thread)
    std::atomic<float> detectedMidi { -1.0f };
    std::atomic<float> correctedMidi { -1.0f };

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();

    void feedDetector (float monoSample);
    void analyse (int keyIdx, int scaleIdx, float speedMs, float amount);
    float yinDetect();
    float readDelay (const std::vector<float>& buf, float delaySamples) const;

    double fs = 44100.0;

    // Pitch shifter (two-tap crossfading delay line)
    std::vector<float> delayBuf[2];
    int delayMask = 0;
    int writePos = 0;
    float grain = 1024.0f;
    float phase = 0.0f;

    // Detector
    int decim = 1;
    int decimCount = 0;
    float decimAcc = 0.0f;
    double detFs = 22050.0;
    std::vector<float> hist;
    int histMask = 0;
    int detWrite = 0;
    int hopSize = 512;
    int hopCounter = 0;
    int tauMin = 0, tauMax = 0;
    std::vector<float> win, dfn, cmnd;
    int unvoicedHops = 0;

    // Correction state
    float hopOffset = 0.0f;     // semitones, after retune-speed smoothing (per hop)
    float smoothOffset = 0.0f;  // semitones, per-sample smoothing
    float sampleSmoothCoeff = 0.01f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (AfroTuneProcessor)
};
