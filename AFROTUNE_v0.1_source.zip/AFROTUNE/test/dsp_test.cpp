#include "../Source/PluginProcessor.h"
#include <cstdio>
#include <cmath>

static double measureHz (const std::vector<float>& x, double fs)
{
    // autocorrelation over the last 8192 samples
    const int N = 8192, off = (int) x.size() - N - 2000;
    auto ac0=[&](int lag){double s=0;for(int i=0;i<N;++i)s+=x[off+i]*x[off+i+lag];return s;};
    const int lo=(int)(fs/1000), hi=(int)(fs/70);
    std::vector<double> c(hi+2); double mx=-1e9;
    for (int lag=lo; lag<=hi; ++lag){ c[lag]=ac0(lag); mx=std::max(mx,c[lag]); }
    int bestLag=lo; // first local max reaching 90% of the global max (avoids multiple-period lock)
    for (int lag=lo+1; lag<hi; ++lag) if (c[lag]>=0.9*mx && c[lag]>=c[lag-1] && c[lag]>=c[lag+1]) { bestLag=lag; break; }
    double s0=0,s1=0,s2=0;
    auto ac=[&](int lag){double s=0;for(int i=0;i<N;++i)s+=x[off+i]*x[off+i+lag];return s;};
    s0=ac(bestLag-1); s1=ac(bestLag); s2=ac(bestLag+1);
    double den = s0-2*s1+s2; double r = bestLag + (den!=0 ? 0.5*(s0-s2)/den : 0);
    return fs / r;
}

static double run (double fs, int block, double freq, int harmonics, int scale, int key, float speed, float mix, bool& finite)
{
    AfroTuneProcessor p;
    p.setPlayConfigDetails (1, 1, fs, block);
    p.prepareToPlay (fs, block);
    p.apvts.getParameter ("scale")->setValueNotifyingHost (p.apvts.getParameter ("scale")->convertTo0to1 ((float) scale));
    p.apvts.getParameter ("key")->setValueNotifyingHost (p.apvts.getParameter ("key")->convertTo0to1 ((float) key));
    p.apvts.getParameter ("speed")->setValueNotifyingHost (p.apvts.getParameter ("speed")->convertTo0to1 (speed));
    p.apvts.getParameter ("mix")->setValueNotifyingHost (mix);
    const int total = (int) (fs * 3);
    std::vector<float> out; out.reserve (total);
    juce::AudioBuffer<float> buf (1, block); juce::MidiBuffer midi;
    double ph = 0; finite = true;
    for (int done = 0; done < total; done += block) {
        for (int i = 0; i < block; ++i) {
            double v = 0; for (int h = 1; h <= harmonics; ++h) v += std::sin (ph*h) / h;
            buf.setSample (0, i, (float) (0.3*v)); ph += 2*M_PI*freq/fs;
        }
        p.processBlock (buf, midi);
        for (int i = 0; i < block; ++i) { float v = buf.getSample (0,i); if (!std::isfinite (v) || std::abs (v) > 4) finite = false; out.push_back (v); }
    }
    return measureHz (out, fs);
}

int main ()
{
    juce::ScopedJuceInitialiser_GUI init;
    bool fin;
    struct T { const char* name; double fs; int blk; double f; int harm; int scale; int key; float speed; float mix; double expect; };
    T tests[] = {
      {"sine 225Hz -> A3 (chromatic, hard)",  48000, 256, 225.0, 1, 0, 0, 0, 1, 220.0},
      {"voice-like 228Hz -> A#3 (nearest)",     44100, 512, 228.0, 6, 0, 0, 0, 1, 233.08},
      {"sharp 215Hz -> A3",                   48000, 128, 215.0, 6, 0, 0, 0, 1, 220.0},
      {"A min pent: 247Hz(B3)->A3 or C4",     48000, 480, 238.0, 6, 3, 9, 0, 1, 220.0},
      {"in tune 220Hz stays 220",             48000, 256, 220.0, 6, 0, 0, 0, 1, 220.0},
      {"mix=0 passes dry 225Hz",              48000, 256, 225.0, 6, 0, 0, 0, 0, 225.0},
      {"96k 1-sample-ish block 64, 225Hz",    96000,  64, 225.0, 6, 0, 0, 0, 1, 220.0},
      {"low male 110Hz-ish 113Hz -> A2",      48000, 256, 113.0, 6, 0, 0, 0, 1, 110.0},
    };
    int fails = 0;
    for (auto& t : tests) {
        double hz = run (t.fs, t.blk, t.f, t.harm, t.scale, t.key, t.speed, t.mix, fin);
        double cents = 1200*std::log2 (hz/t.expect);
        bool ok = fin && std::abs (cents) < 25;
        std::printf ("%-42s out=%.2f Hz  expect=%.1f  err=%+.1f cents  finite=%d  %s\n", t.name, hz, t.expect, cents, (int)fin, ok?"PASS":"FAIL");
        fails += !ok;
    }
    // silence
    { AfroTuneProcessor p; p.setPlayConfigDetails(1,1,48000,256); p.prepareToPlay(48000,256);
      juce::AudioBuffer<float> b(1,256); juce::MidiBuffer m; bool ok=true;
      for(int k=0;k<200;++k){b.clear();p.processBlock(b,m);for(int i=0;i<256;++i) if(b.getSample(0,i)!=0.f) ok=false;}
      std::printf ("%-42s %s\n","silence in -> silence out", ok?"PASS":"FAIL"); fails += !ok; }
    std::printf ("\n%d failure(s)\n", fails);
    return fails;
}
